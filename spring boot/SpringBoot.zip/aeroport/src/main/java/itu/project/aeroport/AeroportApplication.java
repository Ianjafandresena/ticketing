package itu.project.aeroport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AeroportApplication {

	public static void main(String[] args) {
		SpringApplication.run(AeroportApplication.class, args);
	}

}
